import socket

class Client:
    """
    TCP Client for Socket Programming Exercise
    
    Fill in the missing code to complete the client
    """

    def __init__(self, server_host='localhost', server_port=9999):
        # TODO: Create a TCP socket (Hint: Use socket.socket() with appropriate parameters)
        
        # TODO: Connect the socket to the server (Hint: Use the connect() method with host, port)
        pass # Delete this line when you add your code

    def send_message(self):
        """Send a message to the server"""
        message = input('Enter your message: ')
        
        # TODO: Convert the message to bytes (Hint: Use the encode() method)
        
        # TODO: Send the message bytes to the server (Hint: Use the send() method)

    def receive_response(self):
        """Receive response from the server"""
        try:
            # TODO: Receive data from the server (Hint: Use recv() method with buffer size 1024)
            
            # TODO: Convert bytes back to string (Hint: Use the decode() method)
            
            response = None  # Replace None with the decoded response
            
            print(f'Server response: {response}')
            
        except Exception as e:
            print(f"Error receiving response: {e}")

    def close_socket(self):
        """Close the socket connection"""
        # TODO: Close the socket (Hint: Use the close() method)
        
        print("Socket closed")

    def run_client(self):
        """Main method to run the client"""
        try:
            # TODO: Call send_message() method
            # TODO: Call receive_response() method
            pass # Delete this line when you add your code
        except Exception as e:
            print(f"Client error: {e}")
        finally:
            # TODO: Call close_socket() method
            pass # Delete this line when you add your code

# Test your client
if __name__ == '__main__':
    server_ip = '' # Replace with the server's IP address
    server_port = 9999  # Replace with the server's port number (default is 9999)
    # TODO: Create a client instance
    # TODO: Run the client
    pass # Delete this line when you add your code