import socket

class Server:

    def __init__(self, server_port=8080):
        # TODO: Create a TCP socket

        # TODO: Bind the socket to the server address and port

        # TODO: Enable the server to accept connections (specify the max number connections)

        pass # remove this line when the TODOs are done

    def capitalize_message(self, message):
        return message.upper()

    def process_message(self):
        while True:

            # TODO: Accept the connection request 
            client_address = None # replace this with the actual client address

            # TODO: Receive a message over the socket (from the requesting client)

            # TODO: Convert the message from bytes to string
            message_str = '' # replace this with the actual message string

            print(f'Received message: {message_str} from {client_address}') # print the received message to the console

            # TODO: Capitalize the message (Hint: Use the capitalize_message method)

            # TODO: Convert the modified message from string to bytes

            # TODO: Send the modified message over the socket (to the requesting client)

            # TODO: Close the socket

if __name__ == '__main__':
    # TODO: Create an instance of the Server class

    # TODO: Call the process_message method to start processing messages
    
    pass # remove this line when the TODOs are done