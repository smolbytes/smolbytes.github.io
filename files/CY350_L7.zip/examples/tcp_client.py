import socket

""" A simple TCP client that can send an HTTP request to a server and print the response."""
class TCPClient:
    def __init__(self, server_ip='127.0.0.128', server_port=8080):
        print("Initializing TCP Client...")
        self.server_ip = server_ip
        self.server_port = server_port
        print(f"Creating TCP socket")
        self.setup_socket()

    def setup_socket(self):       # Create a TCP socket
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.settimeout(5)  # Set a timeout for blocking socket operations

    def establish_connection(self):
        try:
            self.sock.connect((self.server_ip, self.server_port))
            print(f"Connected to server at {self.server_ip}:{self.server_port}")
            return True
        except Exception as e:
            print(f"Error connecting to server: {e}")
            return False

    def build_http_request(self, resource="/"):
        request = f"GET {resource} HTTP/1.1\r\nHost: {self.server_ip}\r\n\r\n"
        return request
    
    def send_request(self, resource="/"):
        if self.establish_connection():
            try:
                request = self.build_http_request(resource)
                self.sock.sendall(request.encode())
                print(f"Sent HTTP request to {self.server_ip}:{self.server_port}")
            except Exception as e:
                print(f"Error sending request: {e}")
        else:
            print("Failed to establish connection. Request not sent.")

    def receive_response(self):
        response = b""
        try:
            while True:
                try:
                    part = self.sock.recv(4096)  # Buffer size is 4096 bytes
                    if not part:
                        break
                    response += part
                    print("Received response from server:")
                    print(response.decode())
                    if response.endswith(b"\r\n\r\n END MESSAGE"):           # An arbitrary end condition since we aren't manipulating flags yet
                        break
                except socket.timeout:
                    print("No response received: Request timed out.")
        except Exception as e:
            print(f"Error receiving response: {e}")

    def close(self):
        self.sock.close()
        print("Socket closed.")

if __name__ == "__main__":
    client = TCPClient()
    resource = input("Enter the resource path (default is '/'): ") or "/"
    client.send_request(resource)
    client.receive_response()
    client.close()