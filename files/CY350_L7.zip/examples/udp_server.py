import socket

""" A simple UDP server class that receives a message, 
swaps the word server with client if present, capitalizes the message,
and sends it back to the client."""

class UDPServer:
    def __init__(self, server_ip = '127.0.0.128', server_port = 8080):
        print("Initializing UDP Server...")
        self.server_ip = server_ip
        self.server_port = server_port
        self.listening = True
        print(f"Creating UDP socket")
        self.setup_socket()
    
    def setup_socket(self):       # Create a UDP listening socket
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind((self.server_ip, self.server_port))
        print(f"Socket bound to {self.server_ip}:{self.server_port}")

    def parse_message(self, message):
        if "server" in message.lower():
            message = message.replace("server", "client")
        return message.upper()
    
    def close_server(self):
        self.sock.close()
        print("Socket closed.")
    
    def listen(self):
        print("Server is listening for incoming messages...")
        while self.listening:
            try:
                data, addr = self.sock.recvfrom(4096)  # Buffer size is 4096 bytes
                message = data.decode()
                print(f"Received message {message} from {addr}: {message}")
                
                response_message = self.parse_message(message)
                self.sock.sendto(response_message.encode(), addr)
                print(f"Sent response to {addr}: {response_message}")
            except Exception as e:
                print(f"Error: {e}")
                break

if __name__ == "__main__":
    server = UDPServer()
    try:
        server.listen()
    except KeyboardInterrupt:
        print("Shutting down server...")
        server.listening = False
    finally:
        server.close_server()

