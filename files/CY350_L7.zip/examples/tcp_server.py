import socket

""" A simple TCP server class that receives a resource request, parses it, and sends back a response."""

class TCPServer:
    def __init__(self, server_ip = '127.0.0.128', server_port = 8080):
        print("Initializing TCP Server...")
        self.server_ip = server_ip
        self.server_port = server_port
        self.listening = True
        print(f"Creating TCP socket")
        self.setup_socket()

        # Set up a simple resource dictionary
        self.resources = {
            "/": "Welcome to the TCP Server!",
            "/hello": "Hello, TCP Client!",
            "/goodbye": "Goodbye from the TCP Server!",
            "/joke": "Why do programmers prefer dark mode? Because light attracts bugs!"
        }

    def setup_socket(self):       # Create a TCP listening socket
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.bind((self.server_ip, self.server_port))
        self.sock.listen(1)  
        print(f"Socket bound to {self.server_ip}:{self.server_port} and listening")

    def parse_request(self, request):
        try:
            lines = request.split("\r\n")
            request_line = lines[0]
            method, resource, _ = request_line.split()
            if method == "GET":
                return method, resource
            else:
                return None, None
        except Exception as e:
            print(f"Error parsing request: {e}")
            return None, None
        
    def build_http_response(self, request):
        # parse the resource and get the corresponding message
        method, resource = self.parse_request(request)
        if method:
            if resource in self.resources:
                body = self.resources[resource]
                status_line = "HTTP/1.1 200 OK\r\n"
            else:
                body = ""
                status_line = "HTTP/1.1 404 Not Found\r\n"
        else:
            body = ""
            status_line = "HTTP/1.1 400 Bad Request\r\n"

        # Build the full HTTP response
        response = (
            status_line +
            "Content-Type: text/plain\r\n" +
            f"Content-Length: {len(body)}\r\n" +
            body +
            "\r\n\r\nEND MESSAGE"
        )
        return response
    
    def close_server(self):
        self.sock.close()
        print("Socket closed.")

    def listen(self):
        print("Server is listening for incoming connections...")
        while self.listening:
            try:
                conn, addr = self.sock.accept()  # Accept a new connection
                print(f"Connection established with {addr}")
                request = b""
                while True:
                    part = conn.recv(4096)  # Buffer size is 4096 bytes
                    if not part:
                        break
                    request += part
                    if request.endswith(b"\r\n\r\n"):  # End of HTTP headers
                        break
                request_str = request.decode()
                print(f"Received request from {addr}:\n{request_str}")

                response = self.build_http_response(request_str)
                conn.sendall(response.encode())
                print(f"Sent response to {addr}:\n{response}")
                conn.close()
                print(f"Connection with {addr} closed.")
            except Exception as e:
                print(f"Error: {e}")
                break

if __name__ == "__main__":
    server = TCPServer()
    try:
        server.listen()
    except KeyboardInterrupt:
        print("Shutting down server...")
        server.listening = False
    finally:
        server.close_server()