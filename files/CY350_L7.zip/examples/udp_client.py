import socket

""" A simple UDP client class that can send and receive messages."""
class UDPClient:
    def __init__(self, server_ip='127.0.0.128', server_port=8080):
        print("Initializing UDP Client...")
        self.server_ip = server_ip
        self.server_port = server_port
        print(f"Creating UDP socket")
        self.setup_socket()


    def setup_socket(self):       # Create a UDP socket
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.settimeout(5)  # Set a timeout for blocking socket operations

    def send_message(self, message="hello!"):
        try:
            # Send the HTTP request to the server
            self.sock.sendto(message.encode(), (self.server_ip, self.server_port))
            print(f"Sent message to {self.server_ip}:{self.server_port}")
        except Exception as e:
            print(f"Error sending request: {e}")

    def receive_response(self):
        response = False
        while not response:
            try:
                # Receive the response from the server
                response, _ = self.sock.recvfrom(4096)  # Buffer size is 4096 bytes
                print("Received response from server:")
                print(response.decode())
            except socket.timeout:
                print("No response received: Request timed out. Continuing to listen...")
            except Exception as e:
                print(f"Error receiving response: {e}")

    def close(self):
        self.sock.close()
        print("Socket closed.")

if __name__ == "__main__":
    client = UDPClient()
    message = input("Enter your message: ") or "hello, udp server!"
    client.send_message(message)
    client.receive_response()
    client.close()