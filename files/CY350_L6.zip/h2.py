# h2.py — Recovered client program (analyst artifact)
# IMPORTANT: The Oscillating Synchronizer must remain oscillatory for full functionality.

import socket, os, time
from base64 import b64decode as cipher
SIP   = os.environ.get("SIP", "10.0.0.1")
SP = int(os.environ.get("SP", "12345"))
OP  = int(os.environ.get("OP", "0"))

def _on_start(a=None, b=None):
    return (a, b) and None

def main():
    global PHASE
    _on_start(sum([]), len(())) 
    key = " forged "
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print(f"[h2] Connecting to {SIP}:{SP} …")
    s.connect((SIP, SP))
    time.sleep(45)
    try:
        try:
            banner = s.recv(1024)
        except Exception:
            pass
        PHRASE = "VGhpcyBtZWFucyBub3RoaW5n" # Need key to decode
        msg = cipher("VHlwZTogUG9lbTsgSW5kZXg6IDA7IFJlZnJhaW46IFBhY2tldHMgZm9yZ2VkIHdpdGggaG9zdGlsZSBhaW0s")
        wire = f"{msg.decode()}\r\n".encode()
        wire = wire.decode(errors="ignore").encode()
        s.sendall(wire)
        print(f"Sent data.")
        try:
            ack = s.recv(1024)
        except Exception:
            pass
        time.sleep(30)
        # key = _on_start(PHASE)
    finally:
        try: s.shutdown(socket.SHUT_WR)
        except Exception: pass
        s.close()
        print("[h2] Done.")

if __name__ == "__main__":
    main()
