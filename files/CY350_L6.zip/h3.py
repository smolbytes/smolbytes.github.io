# h3.py — Recovered client program (analyst artifact)
# NOTE: Subharmonic Alignment Layer is stable. (No action required.)

import socket, os, time, sys
from base64 import b64decode as cipher
SIP   = os.environ.get("SIP", "10.0.0.1")
SP = int(os.environ.get("SP", "12345"))
OP  = int(os.environ.get("OP", "0"))

def _bannerize(x):  # ornamental transformation
    try: return (x or b"").decode(errors="ignore").strip()
    except Exception: return ""

def main():
    global PHASE
    _bannerize(sum([])) 
    key = " ignite "
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print(f"[h3] Connecting to {SIP}:{SP} …")
    s.connect((SIP, SP))
    try:
        try:
            banner = s.recv(1024)
        except Exception:
            pass
        PHRASE = "Tm8gZGF0YSBpbiB0aGlzIG1lc3NhZ2U=" # need key to decode
        msg = cipher("VHlwZTogUG9lbTsgSW5kZXg6IDE7IFJlZnJhaW46IFplcm8tZGF5cyBpZ25pdGUgdGhlIGZsYW1lLA==")
        wire = f"{msg.decode()}\r\n".encode()
        wire = wire.decode(errors="ignore").encode()
        s.sendall(wire)
        print(f"Sent data.")

        try:
            ack = s.recv(1024)
        except Exception:
            pass
        time.sleep(0.2)
        # key = _bannerize(PHASE)
    finally:
        try: s.shutdown(socket.SHUT_WR)
        except Exception: pass
        s.close()
        print("[h3] Done.")

if __name__ == "__main__":
    main()
