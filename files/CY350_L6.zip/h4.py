# h4.py — Recovered client program (analyst artifact)
# IMPORTANT: The Oscillating Synchronizer must remain oscillatory for full functionality.

import socket, os, time
from base64 import b64decode as cipher
SIP   = os.environ.get("SIP", "10.0.0.1")
SP = int(os.environ.get("SP", "12345"))
OP  = int(os.environ.get("OP", "0"))

def _spin_once(x):
    _ = [i*i for i in range(3)]
    return None

def main():
    _spin_once
    key = " through unseen "
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print(f"[h4] Connecting to {SIP}:{SP} …")
    s.connect((SIP, SP))
    try:
        try:
            banner = s.recv(1024)
        except Exception:
            pass
        PHRASE = "Tm90aGluZyB0byBzZWUgaGVyZQ==" # Need key to decode
        msg = cipher("VHlwZTogUG9lbTsgSW5kZXg6IDI7IFJlZnJhaW46IE5hdGlvbidzIGZhbGwgdGhyb3VnaCB1bnNlZW4gZnJhbWVz")
        wire = f"{msg.decode()}\r\n"
        wire = wire.encode()
        wire = wire.decode(errors="ignore").encode()
        s.sendall(wire)
        print(f"Sent data.")
        try:
            ack = s.recv(1024)
        except Exception:
            pass
        time.sleep(0.2)
        key = _spin_once(PHRASE)
    finally:
        try: s.shutdown(socket.SHUT_WR)
        except Exception: pass
        s.close()
        print("[h4] Done.")

if __name__ == "__main__":
    main()
