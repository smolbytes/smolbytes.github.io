from http.server import HTTPServer, BaseHTTPRequestHandler
import urllib.parse
import os

class VulnerableHandler(BaseHTTPRequestHandler):
    
    def do_GET(self):
        # Parse the URL and query parameters
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path
        params = urllib.parse.parse_qs(parsed_path.query)
        
        # Get cookies from request
        cookies = {}
        if 'Cookie' in self.headers:
            cookie_header = self.headers['Cookie']
            for cookie in cookie_header.split(';'):
                if '=' in cookie:
                    key, value = cookie.split('=', 1)
                    cookies[key.strip()] = value.strip()
        
        print(f"Request: {path}")
        print(f"Cookies: {cookies}")
        
        # Route handling
        if path == '/':
            self.send_homepage()
        elif path == '/login':
            self.handle_login(params)
        elif path == '/user':
            self.send_user_page(cookies)
        elif path == '/admin':
            self.send_admin_page(cookies)
        elif path == '/reset-role':
            html = """<html><body><h1>Role Reset</h1><p>Role cookie reset to 'basic'. <a href="/user">Return to dashboard</a></p></body></html>"""
            self.send_response(200)
            self.send_header('Set-Cookie', 'role=basic')  # Just overwrite with basic
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.end_headers()
            self.wfile.write(html.encode('utf-8'))
        else:
            self.send_404()
    
    def send_homepage(self):
        html = """
        <html>
        <head><meta charset="UTF-8"></head>
        <body style="font-family: Arial; margin: 40px;">
        <h1>🏛️ USMA West Point Portal</h1>
        <p>Welcome to the United States Military Academy secure portal system.</p>
        
        <div style="margin: 20px 0; padding: 20px; background: #f8f9fa; border-radius: 5px;">
            <h3>Login Form:</h3>
            <form action="/login" method="GET" style="margin: 10px 0;">
                <div style="margin: 10px 0;">
                    <label>Username: </label>
                    <input type="text" name="user" value="cadet" style="padding: 5px; margin-left: 10px;">
                </div>
                <div style="margin: 10px 0;">
                    <label>Password: </label>
                    <input type="password" name="pass" value="password123" style="padding: 5px; margin-left: 12px;">
                </div>
                <input type="submit" value="Login" style="background: #007bff; color: white; padding: 8px 16px; border: none; border-radius: 3px; cursor: pointer;">
            </form>
        </div>
        
        <div style="margin-top: 20px; padding: 10px; background: #e9ecef; border-radius: 3px;">
            <small><strong>Demo Accounts:</strong><br>
            Cadet: cadet/password123<br></small>
        </div>
        </body></html>
        """        
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(html.encode('utf-8'))))
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))
    
    def handle_login(self, params):
        username = params.get('user', [''])[0]
        password = params.get('pass', [''])[0]
        print("params:", params)
        print("username:", username)
        print("password:", password)
        
        # Vulnerable authentication
        if username == 'cadet' and password == 'password123':
            cookie_value = 'user=cadet;role=basic;auth=true'
            redirect_url = '/user'
        elif username == 'admin' and password == 'admin123':
            cookie_value = 'user=admin;role=admin;auth=true'  
            redirect_url = '/user'
        else:
            # Failed login
            html = """
            <html>
            <head><meta charset="UTF-8"></head>
            <body style="font-family: Arial; margin: 40px;">
            <h1>❌ Login Failed</h1>
            <p>Invalid credentials. <a href="/">Try again</a></p>
            </body></html>
            """
            self.send_response(401)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(html.encode('utf-8'))))
            self.end_headers()
            self.wfile.write(html.encode('utf-8'))
            return
        
        # Successful login - set cookie and redirect
        print(f"LOGIN SUCCESS: Setting cookie: {cookie_value}")
        self.send_response(302)
        self.send_header('Location', redirect_url)
        cookies = cookie_value.split(";")
        for cur_cookie in cookies:
            self.send_header('Set-Cookie', cur_cookie)
        self.end_headers()
    
    def send_user_page(self, cookies):
        if not cookies.get('auth') == 'true':
            self.send_login_required()
            return
        
        user = cookies.get('user', 'unknown')
        role = cookies.get('role', 'none')
        
        html = f"""
        <html>
        <head><meta charset="UTF-8"></head>
        <body style="font-family: Arial; margin: 40px;">
        <h1>👤 User Dashboard</h1>
        <p><strong>Welcome, {user}!</strong></p>
        <p>Your role: <span style="background: #e9ecef; padding: 2px 8px; border-radius: 3px;">{role}</span></p>
        
        <div style="margin: 20px 0;">
            <h3>Available Resources:</h3>
            <ul>
                <li>📅 Training Schedule</li>
                <li>🍽️ Mess Hall Hours</li>
                <li>📋 Personal Records</li>
            </ul>
        </div>
        
        <div style="margin: 20px 0;">
            <a href="/admin" style="background: #dc3545; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
            🔒 Try Admin Panel</a>
        </div>
        
        <div style="margin-top: 30px; padding: 15px; background: #f8f9fa; border-radius: 5px;">
            <strong>🛠️ Developer Tools Exercise:</strong><br>
            <small>Open your browser's Developer Tools (F12) → Storage → Cookies<br>
            Try modifying the 'role' cookie value and refreshing the page!</small>
        </div>
        </body></html>
        """
        
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(html.encode('utf-8'))))
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))
    
    def send_admin_page(self, cookies):
        user_role = cookies.get('role', 'none')
        
        if user_role != 'admin':
            html = """
            <html>
            <head><meta charset="UTF-8"></head>
            <body style="font-family: Arial; margin: 40px;">
            <h1>🚫 ACCESS DENIED</h1>
            <p style="color: red;"><strong>CLASSIFIED - ADMIN PRIVILEGES REQUIRED</strong></p>
            <p>Your current role does not permit access to this resource.</p>
            <a href="/user">← Back to User Dashboard</a>
            </body></html>
            """
            self.send_response(403)
        else:
            # VULNERABLE: Trust the cookie value without server-side validation!
            html = """
            <html>
            <head><meta charset="UTF-8"></head>
            <body style="font-family: Arial; margin: 40px; background: #fff3cd; border: 2px solid #856404;">
            <h1>⚠️ CLASSIFIED ADMIN PANEL</h1>
            <div style="background: #d4edda; padding: 15px; border-radius: 5px; margin: 20px 0;">
                <h3>🔐 SENSITIVE MILITARY INFORMATION:</h3>
                <ul>
                    <li><strong>Base Security Code:</strong> ALPHA-7742-DELTA</li>
                    <li><strong>Next Deployment:</strong> Operation Thunder - 0800 hours</li>
                    <li><strong>Personnel Count:</strong> 847 active duty, 123 reserves</li>
                    <li><strong>Supply Inventory:</strong> $2.4M in equipment</li>
                </ul>
            </div>
            
            <div style="background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;">
                <h3>🚨 CRITICAL VULNERABILITY DEMONSTRATED!</h3>
                <p>If you're seeing this page after manipulating cookies, you've just demonstrated a serious security flaw!</p>
                <p><strong>The server trusted client-side data without verification.</strong></p>
            </div>
            </body></html>
            """
            self.send_response(200)
            print("⚠️  SECURITY ALERT: Admin panel accessed!")
            
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(html.encode('utf-8'))))
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))
    
    def send_login_required(self):
        html = """
        <html>
        <head><meta charset="UTF-8"></head>
        <body style="font-family: Arial; margin: 40px;">
        <h1>🔐 Authentication Required</h1>
        <p>You must login to access this resource.</p>
        <a href="/">← Return to Login</a>
        </body></html>
        """
        self.send_response(401)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(html.encode('utf-8'))))
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))
    
    def send_404(self):
        html = """
        <html>
        <head><meta charset="UTF-8"></head>
        <body style="font-family: Arial; margin: 40px;">
        <h1>404 - Page Not Found</h1>
        <p>The requested resource was not found on this server.</p>
        <a href="/">← Return to Home</a>
        </body></html>
        """
        self.send_response(404)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(html.encode('utf-8'))))
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))

if __name__ == '__main__':
    server = HTTPServer(('localhost', 8080), VulnerableHandler)
    print("🌐 Vulnerable Web Server running at http://localhost:8080")
    print("📚 Educational demonstration - shows cookie manipulation vulnerability")
    print("🔍 Watch the console for request logs...")
    print("🛑 Press Ctrl+C to stop")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 Server stopped")