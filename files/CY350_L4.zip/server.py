#!/usr/bin/env python3

import time
from mininet.net import Mininet
from mininet.node import OVSSwitch
from mininet.cli import CLI
from mininet.log import setLogLevel, info

def webServerNet():
    """Create a network with a web server and client"""
    net = Mininet(controller=None, switch=OVSSwitch)  # no controller

    info('*** Adding hosts\n')
    client = net.addHost('h1')
    server = net.addHost('h2')

    # Put the switch in standalone (normal) mode so it forwards without a controller
    info('*** Adding switch\n')
    s1 = net.addSwitch('s1', failMode='standalone')

    info('*** Creating links\n')
    net.addLink(server, s1)
    net.addLink(client, s1)

    info('*** Starting network\n')
    net.start()

    info('*** Setting up web server on h1\n')
    server.cmd('mkdir -p /tmp/www')
    html_content = "<html><body><h1>Welcome to CY350 HTTP Lesson Web Server!</h2><p>This server is running on host h2</p></body></html>"
    server.cmd(f"echo \'{html_content}\' > /tmp/www/index.html", shell=True)

    info('*** Starting HTTP server on h1\n')
    server.cmd('cd /tmp/www && python3 -m http.server 80 &')

    info('*** Waiting for server to start...\n')
    net.pingAll()
    server_ip = server.IP()
    info(f'*** Server IP: {server_ip}\n')

    time.sleep(.5) 
    info('*** Testing connectivity\n')
    result = client.cmd(f'curl -s http://{server_ip}', shell=True)
    if 'CY350' in result:
        info('*** Web server is working!\n')
    else:
        info('*** Warning: Server may not be ready yet\n')

    info('*** Running CLI. Try:\n')
    info('*** h2 netstat -ln | grep 80\n')
    info('*** h1 curl -v http://10.0.0.2/index.html\n')
    info('*** h1 curl -v http://10.0.0.2\n')
    info('*** h1 curl -v http://10.0.0.2/nonexistent.htm\n')
    info('*** h1 curl -v -I  http://10.0.0.2\n')
    info('*** h1 curl -v -H "User-Agent: CY350 Scannner" http://10.0.0.2\n')

    CLI(net)
    info('*** Stopping network\n')
    net.stop()

if __name__ == '__main__':
    setLogLevel('info')
    webServerNet()
